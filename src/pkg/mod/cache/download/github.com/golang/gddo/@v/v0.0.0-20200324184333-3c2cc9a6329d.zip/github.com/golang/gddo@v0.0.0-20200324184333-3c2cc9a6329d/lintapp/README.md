lintapp
=======

This directory contains the source for [go-lint.appspot.com](http://go-lint.appspot.com).

Development Environment Setup
-----------------------------

- Copy `app.yaml` to `prod.yaml` and put in the authentication data.
- Install Go App Engine SDK.
- Run the server using the `goapp serve prod.yaml` command.
