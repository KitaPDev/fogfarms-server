package main

import "fmt"

func main() {
	// START HELLO OMIT
	fmt.Println("Hello, World!") // HLhello
	// END HELLO OMIT
}
